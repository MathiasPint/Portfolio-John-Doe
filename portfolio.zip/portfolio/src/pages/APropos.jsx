import React from 'react';
import about from "../images/about.jpg"

const APropos= () => {
  return (
    <div className="text-center">
      <h1 className="display-4"><strong>A propos</strong></h1>
      <img src={about} alt="About" />
    </div>
  );
};

export default APropos;
