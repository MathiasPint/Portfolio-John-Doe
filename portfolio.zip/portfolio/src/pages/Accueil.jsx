import React from 'react';
import herobg from '../images/herobg.jpg';
import '../styles/accueil.css'


function Accueil () {
  return (
    <div className="text-center">
      <h1 className="display-4">Bienvenue sur mon Portfolio</h1>
      <p className="lead">Je suis développeur web React.js</p>
      <img src={herobg} alt="Image d'accueil"/>
    </div>
    
  );
 }

export default Accueil;
