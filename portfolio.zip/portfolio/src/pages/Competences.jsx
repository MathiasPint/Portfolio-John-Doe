import React from 'react';

const Competences= () => {
  return (
    <div className="text-center">
      <h1 className="display-4">Bienvenue sur mon Portfolio</h1>
      <p className="lead">Je suis développeur web React.js</p>
    </div>
  );
};

export default Competences;
